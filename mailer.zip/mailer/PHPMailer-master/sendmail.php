<?php

    ini_set('max_execution_time', 0);
    require 'PHPMailer-master/src/PHPMailer.php';
    require 'PHPMailer-master/src/SMTP.php';

    // init time
    $time_start = microtime(true); 

    // get users in a array
    $csv_target_dir = "uploads/";
    $csv_target_file = $csv_target_dir . basename($_FILES["usersCsv"]["name"]);
    if (!move_uploaded_file($_FILES["usersCsv"]["tmp_name"], $csv_target_file)) {
        echo "Something went wrong while uploading users csv.";
    } 

    $usersData = trim(file_get_contents($csv_target_file));
    $usersData = explode("\n", $usersData);

    
    // get template in a variable
    $template_target_dir = "uploads/";
    $template_target_file = $template_target_dir . basename($_FILES["emailTemplate"]["name"]);
    $uploadOk = 1;

    if (!move_uploaded_file($_FILES["emailTemplate"]["tmp_name"], $template_target_file)) {
        echo "Something went wrong while uploading email template.";
    }
    $emailBody = trim(file_get_contents($template_target_file));

    // user two for loop & create batch total users / number of smtps and send emails sequentially.
    $batchSize = floor(sizeof($usersData)/sizeof($_POST['smtpSecure']));
    $currentSmtp = 0;
    for($i=1; $i<sizeof($usersData); $i = $i+$batchSize){
        for($j=$i; $j<$i+$batchSize-1; $j++){
       //     $email = new PHPMailer\PHPMailer\PHPMailer();
          use PHPMailer\PHPMailer\PHPMailer;
$email = new PHPMailer();

           
            $email->IsSMTP();
            $email->SMTPAuth = true;
            $email->SMTPSecure = $_POST['smtpSecure'][$currentSmtp];
            $email->Host = $_POST['host'][$currentSmtp];
            $email->Port = $_POST['port'][$currentSmtp];
            $email->Username = $_POST['username'][$currentSmtp];
            $email->Password = $_POST['password'][$currentSmtp];
            $email->SetFrom($_POST['setFrom'][$currentSmtp]);
            $email->AddAddress($usersData[$j]);
            $email->Subject = $_POST['mailSubject'];
            $email->Body = $emailBody;
            if(!$email->Send()) {
                echo "Error: $usersData[$j] \n";
            }
        }
        $currentSmtp++;
    }

    // remove template file
    unlink($csv_target_file);
    unlink($template_target_file);

    $time_end = microtime(true);
    echo "Total execution time: ".round($time_end - $time_start);


?>