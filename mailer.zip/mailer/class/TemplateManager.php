<?php

class TemplateManager{
    public static function replacePlaceholderValues($placeholder=array(), $values=array(), $template=""){
        $len = sizeof($placeholder);
        for($i=0; $i<$len; $i++){
            $label = strtoupper("##".$placeholder[$i]."##");
            while(str_contains($template, $label)){
                $template = str_replace($label, $values[$i], $template);
            }
            
        }
        return $template;
    }
}

?>